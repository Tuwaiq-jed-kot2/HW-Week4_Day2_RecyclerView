package com.shady.hw_week04_day01_recyclerviewiml

import java.util.*

data class Info(
    val id : UUID = UUID.randomUUID(),
    var name:String=""

    ) {
}