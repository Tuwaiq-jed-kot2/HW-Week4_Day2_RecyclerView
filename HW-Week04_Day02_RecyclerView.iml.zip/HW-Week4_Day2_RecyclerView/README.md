# RecyclerView Project
---
- Create a useful example of recyclerView that displays at least 15 items, each item content of two text views. When click on any item will show Toast message that display id of clicked item.
> *Optional:* add an image in the item, thus the item has one image and two text views.

# Constraint Project (Optional) 
- convert all the root elements of layouts in the Geoguiz and crimnailintent to constraint layout. 
